from django.apps import AppConfig


class CurdConfig(AppConfig):
    name = 'Curd'
